﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using SpreadsheetLight;
using ListasInformacion;
using GeneradorInstrumentacionAvance;

namespace LectorInstrumentacionAvance
{
    public partial class FrmSeleccionarInstrumentacion : Form
    {
        string DireccionArchivo; // Para almacenar la direccion del archivo seleccionado
        public FrmSeleccionarInstrumentacion()
        {
            InitializeComponent();
            DireccionArchivo = "";
        }

    

        private void FrmSeleccionar_Load(object sender, EventArgs e)
        {
            BtnAceptar.Enabled = false;
            PbCarga.Visible = false;
            lblCargando.Text = "";
            TxtArchivo.Enabled = false;

        }
        

        private void BtnSeleccionar_Click(object sender, EventArgs e)
        {
            OpenFileDialog AbrirArchivo = new OpenFileDialog();
            AbrirArchivo.Title = "Seleccionar un Archivo";
            AbrirArchivo.Filter = "Archivos de Excel (*.xls;*.xlsx)|*.xls;*.xlsx"; // Para evitar que se seleccionen archivos que no sean xls o xlsx 
            AbrirArchivo.FileName = this.TxtArchivo.Text;



            if (AbrirArchivo.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.TxtArchivo.Text = AbrirArchivo.FileName;
                this.DireccionArchivo = TxtArchivo.Text;
            }
            if (TxtArchivo.Text == "")
            {
                BtnAceptar.Enabled = false;
            }
            else
            {
                BtnAceptar.Enabled = true;
            }
        }

        private void BtnAceptar_Click(object sender, EventArgs e)
        {
            NuevaCarga();
            Archivo mArchivo = new Archivo(DireccionArchivo);
            if (mArchivo.AbrirArchivo())
            {

                float porcentaje = 0;
                SLDocument libro;
                libro = new SLDocument(DireccionArchivo);
                string[] hojas = libro.GetWorksheetNames().ToArray();
                PbCarga.Maximum = hojas.Length;
                float carga = 100 / (hojas.Length);
                for (int i = 0; i < hojas.Length; i++)
                {
                    if (hojas[i] == "Docentes") continue;
                    porcentaje = porcentaje + carga;
                    BtnSeleccionar.Enabled = false;

                    if (mArchivo.LeerArchivo(hojas[i]))
                    {
                        lblCargando.Text = "cargando.." + porcentaje + "%";
                        this.Text = "cargando... " + porcentaje + "%";
                        lblHojas.Text = "Hojas leidas: " + i;
                        PbCarga.PerformStep();
                    }
                }
                FinCarga();

                //Mostrar el formulario para seleccionar la ubicacion
                FrmSeleccionarUbicacion mFrmSeleccionar = new FrmSeleccionarUbicacion();
                mFrmSeleccionar.ShowDialog();
            }
            else
            {
                ArchivoCorrupto();
            }
        }

        private void BtnCancelar_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        public void NuevaCarga()
        {
            this.Text = "Cargando...";
            lblCargando.Text = "Cargando...";
            BtnCancelar.Enabled = false;
            lblCargando.Visible = true;
            PbCarga.Value = 0;
            PbCarga.Visible = true;
            BtnSeleccionar.Enabled = false;
            BtnAceptar.Enabled = false;
        }
        public void FinCarga()
        {
            this.Text = "Selecionar Archivo";
            PbCarga.Value = PbCarga.Maximum;
            BtnAceptar.Enabled = false;
            BtnSeleccionar.Enabled = true;
            DgvLista.DataSource = Listas.ListaInstrumentaciones;
            lblCargando.Text = "Carga Completada";
        }
        public void ArchivoCorrupto()
        {
            lblCargando.Text = "Error en el archivo";
            PbCarga.Value = PbCarga.Maximum;
            lblHojas.Text = "Hojas leidas: 0";
            BtnSeleccionar.Enabled = true;
            this.Text = "Selecionar Archivo";
        }
    }
}
