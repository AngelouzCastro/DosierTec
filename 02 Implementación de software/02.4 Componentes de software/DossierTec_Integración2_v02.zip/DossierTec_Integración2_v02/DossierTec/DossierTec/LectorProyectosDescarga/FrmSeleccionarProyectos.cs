﻿using ListasInformacion;
using SpreadsheetLight;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LectorProyectosDescarga
{
    public partial class FrmSeleccionarProyectos : Form
    {
        private string RutaArchivo;
        private Archivo mArchivo;
        public FrmSeleccionarProyectos()
        {
            InitializeComponent();
            BtnCargar.Enabled = false;
            TxtArchivo.Enabled = false;
            
        }

        

        private void BtnSeleccionar_Click(object sender, EventArgs e)
        {
            OpenFileDialog AbrirArchivo = new OpenFileDialog();
            AbrirArchivo.Title = "Seleccionar un Archivo";
            AbrirArchivo.Filter = "Archivos de Excel (*.xls;*.xlsx)|*.xls;*.xlsx"; // Para evitar que se seleccionen archivos que no sean xls o xlsx 
            AbrirArchivo.FileName = this.TxtArchivo.Text;

            if (AbrirArchivo.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.TxtArchivo.Text = AbrirArchivo.FileName;
                this.RutaArchivo = TxtArchivo.Text;
            }
            if (TxtArchivo.Text == "")
            {
                BtnCargar.Enabled = false;
            }
            else
            {
                BtnCargar.Enabled = true;
            }
        }

        private void BtnCargar_Click(object sender, EventArgs e)
        {
            mArchivo = new Archivo();
            mArchivo.RutaArchivo = this.RutaArchivo;
            if (mArchivo.AbrirArchivo())
            {
                mArchivo.LeerArchivo("Docentes");
                DtgLista.DataSource = Listas.ListaProyectos;
                DtgLista.AutoResizeColumns();
            }
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

      
    }
}
