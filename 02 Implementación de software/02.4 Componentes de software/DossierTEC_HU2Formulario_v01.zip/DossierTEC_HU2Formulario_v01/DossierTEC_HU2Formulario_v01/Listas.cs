﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DossierTEC_HU2Formulario_v01
{
    class Listas
    {
        /// Esta lista sirve para almacenar y validar los datos 
        /// que se usarán para generar el repositorio de Proyectos.
        static public List<Proyecto> ListaProyectos { get; set; }
    }
}
