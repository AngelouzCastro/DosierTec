﻿using SpreadsheetLight;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DossierTEC_HU2Formulario_v01
{
    public partial class FrmPrincipal : Form
    {
        private string RutaArchivo;
        private Archivo mArchivo;
        public FrmPrincipal()
        {
            InitializeComponent();
            BtnCargar.Enabled = false;
            TxtArchivo.Enabled = false;
        }

        private void BtnSeleccionar_Click(object sender, EventArgs e) {
            OpenFileDialog AbrirArchivo = new OpenFileDialog();
            AbrirArchivo.Title = "Seleccionar un Archivo";
            AbrirArchivo.Filter = "Archivos de Excel (*.xls;*.xlsx)|*.xls;*.xlsx"; // Para evitar que se seleccionen archivos que no sean xls o xlsx 
            AbrirArchivo.FileName = this.TxtArchivo.Text;

            if (AbrirArchivo.ShowDialog() == System.Windows.Forms.DialogResult.OK) {
                this.TxtArchivo.Text = AbrirArchivo.FileName;
                this.RutaArchivo = TxtArchivo.Text;
            }
            if (TxtArchivo.Text == ""){
                BtnCargar.Enabled = false;
            }else{
                BtnCargar.Enabled = true;
            }
        }

        private void BtnCargar_Click(object sender, EventArgs e) {
            mArchivo = new Archivo();
            mArchivo.RutaArchivo = this.RutaArchivo;
            if (mArchivo.AbrirArchivo()) {
                SLDocument Libro;
                Libro = new SLDocument(RutaArchivo);
                string[] hojas = Libro.GetWorksheetNames().ToArray();
                for (int i = 0; i < hojas.Length; i++) {
                    if (hojas[i] == "Docentes") {
                        Console.WriteLine(hojas[i]);
                        mArchivo.LeerArchivo(hojas[i]);
                    }
                }
                DtgLista.DataSource = Listas.ListaProyectos;
            }
        }
        private void BtnSalir_Click(object sender, EventArgs e) {
            this.Close();
        }
    }
}
