﻿
namespace DossierTEC_HU2Formulario_v01
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnSeleccionar = new System.Windows.Forms.Button();
            this.LblArchivo = new System.Windows.Forms.Label();
            this.DtgLista = new System.Windows.Forms.DataGridView();
            this.BtnSalir = new System.Windows.Forms.Button();
            this.BtnCargar = new System.Windows.Forms.Button();
            this.TxtArchivo = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.DtgLista)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnSeleccionar
            // 
            this.BtnSeleccionar.BackColor = System.Drawing.SystemColors.Control;
            this.BtnSeleccionar.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.BtnSeleccionar.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.BtnSeleccionar.Location = new System.Drawing.Point(536, 31);
            this.BtnSeleccionar.Name = "BtnSeleccionar";
            this.BtnSeleccionar.Size = new System.Drawing.Size(101, 41);
            this.BtnSeleccionar.TabIndex = 0;
            this.BtnSeleccionar.Text = "Seleccionar";
            this.BtnSeleccionar.UseVisualStyleBackColor = false;
            this.BtnSeleccionar.Click += new System.EventHandler(this.BtnSeleccionar_Click);
            // 
            // LblArchivo
            // 
            this.LblArchivo.AutoSize = true;
            this.LblArchivo.Location = new System.Drawing.Point(23, 55);
            this.LblArchivo.Name = "LblArchivo";
            this.LblArchivo.Size = new System.Drawing.Size(55, 17);
            this.LblArchivo.TabIndex = 1;
            this.LblArchivo.Text = "Archivo";
            // 
            // DtgLista
            // 
            this.DtgLista.BackgroundColor = System.Drawing.SystemColors.Control;
            this.DtgLista.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DtgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DtgLista.Location = new System.Drawing.Point(84, 119);
            this.DtgLista.Name = "DtgLista";
            this.DtgLista.RowHeadersWidth = 51;
            this.DtgLista.RowTemplate.Height = 24;
            this.DtgLista.Size = new System.Drawing.Size(434, 312);
            this.DtgLista.TabIndex = 2;
            // 
            // BtnSalir
            // 
            this.BtnSalir.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.BtnSalir.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.BtnSalir.Location = new System.Drawing.Point(558, 438);
            this.BtnSalir.Name = "BtnSalir";
            this.BtnSalir.Size = new System.Drawing.Size(93, 41);
            this.BtnSalir.TabIndex = 3;
            this.BtnSalir.Text = "Salir";
            this.BtnSalir.UseVisualStyleBackColor = true;
            this.BtnSalir.Click += new System.EventHandler(this.BtnSalir_Click);
            // 
            // BtnCargar
            // 
            this.BtnCargar.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.BtnCargar.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.BtnCargar.Location = new System.Drawing.Point(536, 83);
            this.BtnCargar.Name = "BtnCargar";
            this.BtnCargar.Size = new System.Drawing.Size(101, 42);
            this.BtnCargar.TabIndex = 4;
            this.BtnCargar.Text = "Cargar";
            this.BtnCargar.UseVisualStyleBackColor = true;
            this.BtnCargar.Click += new System.EventHandler(this.BtnCargar_Click);
            // 
            // TxtArchivo
            // 
            this.TxtArchivo.Location = new System.Drawing.Point(84, 50);
            this.TxtArchivo.Name = "TxtArchivo";
            this.TxtArchivo.Size = new System.Drawing.Size(434, 22);
            this.TxtArchivo.TabIndex = 5;
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(672, 503);
            this.Controls.Add(this.TxtArchivo);
            this.Controls.Add(this.BtnCargar);
            this.Controls.Add(this.BtnSalir);
            this.Controls.Add(this.DtgLista);
            this.Controls.Add(this.LblArchivo);
            this.Controls.Add(this.BtnSeleccionar);
            this.Name = "FrmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Proyectos De Descarga";
            ((System.ComponentModel.ISupportInitialize)(this.DtgLista)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnSeleccionar;
        private System.Windows.Forms.Label LblArchivo;
        private System.Windows.Forms.DataGridView DtgLista;
        private System.Windows.Forms.Button BtnSalir;
        private System.Windows.Forms.Button BtnCargar;
        private System.Windows.Forms.TextBox TxtArchivo;
    }
}

