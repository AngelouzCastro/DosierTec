﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DossierTEC_HU2Formulario_v01
{
    class Proyecto
    {
        public Proyecto(){
            Docente = "";
            ProyectoDescarga = "";
        }

        public string Docente { get; set; }
        public string ProyectoDescarga { get; set; }
    }
}
